TRAFFIC POLICE — Android/RuStore project

В проекте уже есть Android WebView-обёртка и HTML-игра.

Для автоматической сборки APK на GitHub используется:
.github/workflows/build-apk.yml

После загрузки проекта в репозиторий GitHub откройте вкладку Actions и запустите
"Build Traffic Police APK". В результате появится artifact "TrafficPolice-APK"
с файлом app-debug.apk.

ВАЖНО: debug APK предназначен для тестовой установки. Для публикации в RuStore
нужна release-сборка с подписью (обычно AAB или подписанный APK) и ключом разработчика.
